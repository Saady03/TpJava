/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javatp;

import java.util.Scanner;

/**
 *
 * @author Utilisateur
 */
public class Javatp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        //declaration des variables
        int NbreEntre=0,NbreMystere=0,NbEssai=0;
        int BorneInf=1, BorneSup=10,Nmax=3;
        int note1=0,note2=0,note3=0,d=0, total=100;
        NbreMystere=4;//choix du nombre mystere
        do
        {
          System.out.println("Imaginez un nombre compris entre 1 et 10");
           // NbreEntre=Utile.lireEntier("Entrer un nombre");
            NbreEntre= scan.nextInt();
            //on verifie si le nombre entre par l'utilisation est plus grand ou plus petit que le nombre mystere
                if(NbreMystere<NbreEntre)
                    {
                    System.out.println("Essai"+NbEssai+ "Le nombre choisi est trop grand");
                    }
                else if(NbreMystere>NbreEntre)
                {
                    System.out.println("Essai"+NbEssai+  "Le nombre choisi est trop petit");
                }
                //determination de la difference des deux nombres
                if(NbreEntre<NbreMystere)
                   {
                       d=NbreMystere-NbreEntre;
                   }
                else
                {
                    d=NbreEntre-NbreMystere;
                }
                if(NbEssai==0)
                {
                    note1=100-(10*d);
                 
                }
                else if(NbEssai==1)
                {
                    note2=90-(9*d);
                   
                }
                else
                {
                   note3=80-(8*d);
                 }
                NbEssai++;
                }
           while((NbreEntre!=NbreMystere)&&NbEssai<Nmax);//tant que cette condition est verifiee on, continue la recherche du nombre
        
        switch (NbEssai){
               
                case 1:
                
                        System.out.println("Bravo vous avez trouve la reponse et vous avez"+total+"/100");
                        break;
                case 2:
                        total=total-10;
                        int score2;
                        score2=(note1+90)/2;
                        System.out.println("Bravo vous avez trouve la reponse et vous avez"+score2+"/100");
                        break;
                       
                case 3:
                            int score3 =(note1+note2+note3)/3;
                            if(NbreEntre==NbreMystere)
                            {
                            System.out.println("Bravo vous avez trouve la reponse et vous avez"+total+"/100");
                            
                            }
                            System.out.println("Votre score est "+score3);
                      break;
                  
     } 
}
}//fin du script
