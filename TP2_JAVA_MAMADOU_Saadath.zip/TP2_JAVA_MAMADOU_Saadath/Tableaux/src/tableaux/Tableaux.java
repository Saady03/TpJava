/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableaux;

import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author Utilisateur
 */
public class Tableaux {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int tab1[] = new int[10];
        int min =50,max=100;//on definit la plage des valeurs
        //fonction de recuperation des nombres aleatoires dans le tableau
        for(int i=0;i<10;i++)
        {
             tab1[i]=ThreadLocalRandom.current().nextInt(min,max+1);      
        }
        //appel des methodes auxiliaires
       Operations(tab1);
       remplir1(tab1);
   }
     static void Operations(int tab1[])//methode auxiliaire qui gere le 1er tableau 
    {
       System.out.println( "Voici le premier tableau :");
        afficher(tab1);
        Operation2(tab1);
        Operation3(tab1);
        Operation4(tab1);
    }
     static void afficher(int t1[])//methode d'affichage du tableau
     { 
         
         for(int i=0;i<t1.length;i++)
         {
          System.out.print(t1[i]+" ");
          
         }
          System.out.println("    ");
    }
    static void Operation2(int t2[])//calcul de la somme
     {
         int som=0;
         for(int i=0;i<t2.length;i++)
            {
             som+=t2[i];
              }
         System.out.println("La somme des éléments est "+som);  
        
     }
   static void Operation3(int t3[])//affichage du maximum
    {
       //initialisation des variables
       double MoyDec=0.0;
       double som1=0.0,som2=0.0;
       for(int i=0;i<t3.length-5;i++)//somme des 5 premiers elements
           som1+=t3[i];
       for(int i=5;i<t3.length;i++)//calcul de la somme du reste des éléments
           som2+=t3[i];
       MoyDec=(2*som1+som2)/t3.length;
       System.out.println("La moyenne décalée des éléments est "+MoyDec);
        //return 0;
    }
   static void Operation4(int t4[])
    {
        int max=0,i;
        max=t4[0];
        for(i=1;i<t4.length;i++)
          {
            if(t4[i]>max)//comparaison du premier element avec le reste 
            {
             max=t4[i] ;
            }
          }
        System.out.println("Le plus grand  élément vaut :"+max);

    }
   static void remplir1(int TabOrd[])//methode qui gere le second tableau
   {
       //ordre croissant des valeurs 
        for(int i=0;i<TabOrd.length;i++)
        {
            for(int j=i+1;j<TabOrd.length;j++)
            {
                if(TabOrd[i]>TabOrd[j])
                {
                    int c=TabOrd[i];
                    TabOrd[i]=TabOrd[j];
                    TabOrd[j]=c;
                   
                   }
                    
            }
        }
        //construction du tableau 2
        int tab2[] = new int[10];
        for(int j=0;j<5;j++)
            {
                
                tab2[j]=TabOrd[j];
            }
         remplir2(tab2,TabOrd);
   }
   static void remplir2(int tab2[],int TabOrd[])
   {//insertion des 5 dernieres valeurs de facon decroissante
      for(int i=5;i<10;i++)
   {
      tab2[i]= TabOrd[14-i];
        
   }
  System.out.println( "Voici le deuxieme tableau :");
  //appel des methodes auxiliaires
  afficher(tab2);
  Operation3(tab2);
 }
}